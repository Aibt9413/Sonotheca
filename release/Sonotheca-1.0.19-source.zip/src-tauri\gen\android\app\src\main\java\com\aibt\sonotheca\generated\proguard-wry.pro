# THIS FILE IS AUTO-GENERATED. DO NOT MODIFY!!

# Copyright 2020-2023 Tauri Programme within The Commons Conservancy
# SPDX-License-Identifier: Apache-2.0
# SPDX-License-Identifier: MIT

-keep class com.aibt.sonotheca.* {
  native <methods>;
}

-keep class com.aibt.sonotheca.WryActivity {
  public <init>(...);

  void setWebView(com.aibt.sonotheca.RustWebView);
  java.lang.Class getAppClass(...);
  int getId();
  java.lang.String getVersion();
  int startActivity(...);
}

-keep class com.aibt.sonotheca.Ipc {
  public <init>(...);

  @android.webkit.JavascriptInterface public <methods>;
}

-keep class com.aibt.sonotheca.RustWebView {
  public <init>(...);

  void loadUrlMainThread(...);
  void loadHTMLMainThread(...);
  void evalScript(...);
}

-keep class com.aibt.sonotheca.RustWebChromeClient,com.aibt.sonotheca.RustWebViewClient {
  public <init>(...);
}
